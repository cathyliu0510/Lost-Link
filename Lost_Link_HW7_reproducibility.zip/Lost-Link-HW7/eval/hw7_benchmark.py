"""Bounded real API benchmark. See eval/hw7_plan.json before running.

python -m eval.hw7_benchmark --phase discovery
# Inspect tuning evidence, make/freeze one change, then:
python -m eval.hw7_benchmark --phase retest
"""
from __future__ import annotations

import argparse
import hashlib
import importlib
import importlib.metadata
import json
import logging
import math
import os
import platform
import statistics
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path

from fastapi.testclient import TestClient
from lostlink import matching
from eval import hw7_original_matching as original

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "eval" / "hw7_evidence"
REPEATS = 3


def read(path):
    return json.loads((ROOT / path).read_text())


def sha(path):
    return hashlib.sha256((ROOT / path).read_bytes()).hexdigest()


def percentile(values, fraction):
    return sorted(values)[max(0, math.ceil(len(values) * fraction) - 1)]


def summarize(rows):
    """Accuracy uses unique cases; latency/bytes use every timing repetition."""
    output = {}
    for split in sorted({r["split"] for r in rows}):
        output[split] = {}
        for arm in sorted({r["arm"] for r in rows}):
            rs = [r for r in rows if r["split"] == split and r["arm"] == arm]
            unique = [r for r in rs if r["repeat"] == 0]
            assert all(r["success"] == next(u["success"] for u in unique
                       if u["query_id"] == r["query_id"]) for r in rs)
            pos = [r for r in unique if r["answer"] is not None]
            neg = [r for r in unique if r["answer"] is None]
            times = [r["latency_ms"] for r in rs]
            output[split][arm] = {
                "unique_cases": len(unique), "search_calls": len(rs),
                "successes": sum(r["success"] for r in unique),
                "positive_hits": sum(r["success"] for r in pos), "positive_n": len(pos),
                "absent_false_suggestions": sum(bool(r["top3"]) for r in neg),
                "absent_n": len(neg),
                "wrong_candidates_mean": round(statistics.mean(r["wrong_candidates"] for r in unique), 3),
                "latency_p50_ms": round(statistics.median(times), 3),
                "latency_p95_ms": round(percentile(times, .95), 3),
                "mean_response_bytes": round(statistics.mean(r["response_bytes"] for r in rs), 1),
                "http_200": sum(r["http_status"] == 200 for r in rs),
                "private_leaks": sum(r["private_leak"] for r in rs),
                "model_calls": 0, "model_tokens": 0, "model_api_usd": 0
            }
    return output


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--phase", choices=["discovery", "retest"], required=True)
    args = ap.parse_args()
    EVIDENCE.mkdir(exist_ok=True)
    # Freeze evidence before the first service request of this phase.
    paths = ["eval/hw7_plan.json", "data/hw7_tuning.json", "data/hw7_fresh.json",
             "data/hw7_extra_found.json", "data/heldout_queries.json",
             "data/synthetic_reports.json", "eval/hw7_benchmark.py",
             "eval/hw7_original_matching.py", "lostlink/matching.py", "lostlink/server.py"]
    manifest = {
        "phase": args.phase, "started_utc": datetime.now(timezone.utc).isoformat(),
        "base_commit": read("eval/hw7_plan.json")["base_commit"],
        "sha256": {p: sha(p) for p in paths}, "python": platform.python_version(),
        "platform": platform.platform(), "processor": platform.machine(),
        "packages": {p: importlib.metadata.version(p) for p in
                     ("fastapi", "starlette", "pydantic", "httpx", "pytest")},
        "repeats": REPEATS, "transport": "in-process ASGI, SQLite, real auth/audit middleware",
        "id_generation": "deterministic sequential IDs for reproducible rank tie ordering",
        "tokens": "ephemeral synthetic local fixture tokens; never exported",
        "latency_scope": "one GET including ASGI/auth/SQLite/audit; excludes seed, registration, model and network"
    }
    manifest_path = EVIDENCE / f"{args.phase}_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
    data = read("data/synthetic_reports.json")
    founds = data["found"] + data["distractors"] + read("data/hw7_extra_found.json")["found"]
    splits = {"tuning": read("data/hw7_tuning.json")["queries"]}
    arms = {"baseline": original.rank_baseline, "original": original.rank_alias}
    if args.phase == "retest":
        splits = {"legacy": read("data/heldout_queries.json")["queries"], **splits,
                  "fresh": read("data/hw7_fresh.json")["queries"]}
        arms["revised"] = matching.rank_alias
    current_ranker = matching.rank_alias
    rows, audit_rows = [], []
    setup_calls = 0
    with tempfile.TemporaryDirectory(prefix="lostlink-hw7-") as td:
        secret_path = Path(td) / "secrets.json"
        secret_path.write_text(json.dumps({"agents": {"synthetic-holder-token": "holder-agent",
                                                     "synthetic-owner-token": "owner-agent"},
                                           "humans": {}}))
        os.environ["LOSTLINK_DB"] = str(Path(td) / "benchmark.db")
        os.environ["LOSTLINK_SECRETS"] = str(secret_path)
        from lostlink import server
        importlib.reload(server)
        logging.getLogger("lostlink").setLevel(logging.WARNING)
        logging.getLogger("httpx").setLevel(logging.WARNING)
        counter = iter(range(1, 100000))
        server.new_id = lambda prefix: f"{prefix}-{next(counter):06d}"
        holder = {"Authorization": "Bearer synthetic-holder-token"}
        owner = {"Authorization": "Bearer synthetic-owner-token"}
        label_to_id = {}
        with TestClient(server.app) as client:
            for f in founds:
                body = {k: v for k, v in f.items() if k not in ("report_id", "answer")}
                body["request_id"] = "seed-" + f["report_id"]
                response = client.post("/v1/reports", json=body, headers=holder)
                response.raise_for_status()
                label_to_id[f["report_id"]] = response.json()["report_id"]
                setup_calls += 1
            id_to_label = {v: k for k, v in label_to_id.items()}
            private_values = [f["private_detail"] for f in founds if f.get("private_detail")]
            for split, queries in splits.items():
                for q in queries:
                    body = {k: v for k, v in q.items() if k not in ("report_id", "answer")}
                    body["request_id"] = "query-" + q["report_id"]
                    response = client.post("/v1/reports", json=body, headers=owner)
                    response.raise_for_status()
                    lost_id = response.json()["report_id"]
                    setup_calls += 1
                    for rep in range(REPEATS):
                        names = list(arms)
                        names = names[rep % len(names):] + names[:rep % len(names)]
                        for name in names:
                            matching.rank_alias = arms[name]
                            start = time.perf_counter_ns()
                            response = client.get(f"/v1/reports/{lost_id}/matches?limit=3", headers=owner)
                            elapsed = (time.perf_counter_ns() - start) / 1e6
                            response.raise_for_status()
                            payload = response.json()
                            top = [id_to_label[c["report_id"]] for c in payload["candidates"]]
                            answer = q["answer"]
                            leak = any(p in response.text for p in private_values) or "private_detail" in response.text
                            rows.append({"split": split, "query_id": q["report_id"], "answer": answer,
                                "arm": name, "repeat": rep, "http_status": response.status_code,
                                "top3": top, "success": (answer in top if answer is not None else not top),
                                "wrong_candidates": sum(c != answer for c in top),
                                "private_leak": leak, "latency_ms": round(elapsed, 6),
                                "response_bytes": len(response.content), "response": payload})
            conn = server.get_db()
            audit_rows = [dict(r) for r in conn.execute("SELECT * FROM audit_log ORDER BY rowid")]
            report_n = conn.execute("SELECT count(*) FROM reports").fetchone()[0]
            conn.close()
        matching.rank_alias = current_ranker
    (EVIDENCE / f"{args.phase}_rows.jsonl").write_text("".join(json.dumps(r, sort_keys=True) + "\n" for r in rows))
    (EVIDENCE / f"{args.phase}_audit.jsonl").write_text("".join(json.dumps(r, sort_keys=True) + "\n" for r in audit_rows))
    summary = {"metrics": summarize(rows), "search_calls": len(rows), "setup_calls": setup_calls,
               "audit_rows": len(audit_rows), "reports_in_db": report_n,
               "model_calls": 0, "model_tokens": 0, "model_api_usd": 0,
               "finished_utc": datetime.now(timezone.utc).isoformat()}
    assert len(audit_rows) == len(rows) + setup_calls
    assert all(not r["private_leak"] for r in rows)
    (EVIDENCE / f"{args.phase}_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
