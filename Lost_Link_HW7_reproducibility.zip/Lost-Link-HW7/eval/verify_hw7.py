"""Independently re-score saved API responses against frozen fixture labels."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
E = ROOT / "eval/hw7_evidence"


def load(path):
    return json.loads((ROOT / path).read_text())


def main():
    data = load("data/synthetic_reports.json")
    founds = data["found"] + data["distractors"] + load("data/hw7_extra_found.json")["found"]
    by_id = {f"F-{i:06d}": f["report_id"] for i, f in enumerate(founds, 1)}
    queries = {q["report_id"]: q for path in
               ("data/heldout_queries.json", "data/hw7_tuning.json", "data/hw7_fresh.json")
               for q in load(path)["queries"]}
    total = 0
    for phase in ("discovery", "retest"):
        rows = [json.loads(line) for line in (E / f"{phase}_rows.jsonl").read_text().splitlines()]
        summary = load(f"eval/hw7_evidence/{phase}_summary.json")
        for r in rows:
            top = [by_id[c["report_id"]] for c in r["response"]["candidates"]]
            answer = queries[r["query_id"]]["answer"]
            assert top == r["top3"] and answer == r["answer"]
            assert r["success"] == (answer in top if answer is not None else not top)
            assert r["wrong_candidates"] == sum(c != answer for c in top)
            assert r["http_status"] == 200
            assert "private_detail" not in json.dumps(r["response"])
        for split, arms in summary["metrics"].items():
            for arm, expected in arms.items():
                rs = [r for r in rows if r["split"] == split and r["arm"] == arm and r["repeat"] == 0]
                assert len(rs) == expected["unique_cases"]
                assert sum(r["success"] for r in rs) == expected["successes"]
                assert sum(bool(r["top3"]) for r in rs if r["answer"] is None) == expected["absent_false_suggestions"]
        audit = (E / f"{phase}_audit.jsonl").read_text().splitlines()
        assert len(audit) == summary["setup_calls"] + len(rows)
        total += len(rows)
    discovery = load("eval/hw7_evidence/discovery_manifest.json")["sha256"]
    retest = load("eval/hw7_evidence/retest_manifest.json")["sha256"]
    original = hashlib.sha256((ROOT / "eval/hw7_original_matching.py").read_bytes()).hexdigest()
    assert original == discovery["lostlink/matching.py"] == retest["eval/hw7_original_matching.py"]
    for path in ("data/hw7_fresh.json", "data/hw7_tuning.json", "eval/hw7_plan.json"):
        assert discovery[path] == retest[path] == hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
    assert retest["lostlink/matching.py"] == hashlib.sha256((ROOT / "lostlink/matching.py").read_bytes()).hexdigest()
    print(f"PASS: {total} saved API responses re-scored against fixture answers; 330 audit rows reconciled.")
    print("PASS: original source matches pre-change hash; plan/case hashes unchanged; revised source matches retest freeze.")


if __name__ == "__main__":
    main()
